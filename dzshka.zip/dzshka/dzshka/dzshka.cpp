﻿#include <iostream>
#include <vector>
#include <chrono>
int linearSearch(std::vector<int>& data, int target, int n)
{
    for (int i = 0; i < n; i++)
    {
        if (data[i] == target)
        {
            return 1;
        }
    }
    return 0;
}
int binarySearch(std::vector<int>& data, int target, int n)
{
    int left = 0;
    int right = n - 1;

    while (left <= right)
    {
        int mid = left + (right - left) / 2;

        if (data[mid] == target)
        {
            return 1;
        }
        else if (data[mid] < target)
        {
            left = mid + 1;
        }
        else
        {
            right = mid - 1;
        }
    }
    return 0;
}
int main()
{
    setlocale(LC_ALL, "RU");
    const int N = 100000;
    std::vector<int> ids(N);
    for (int i = 0; i < N; i++)
    {
        ids[i] = i + 1;
    }
    int target = ids[N - 1];
    std::chrono::time_point start = std::chrono::steady_clock::now();
    for (int i = 0; i < 10000; i++)
    {
        linearSearch(ids, target, N);
    }
    std::chrono::time_point end = std::chrono::steady_clock::now();
    std::chrono::duration<double, std::milli> linearTime = end - start;
    start = std::chrono::steady_clock::now();
    for (int i = 0; i < 10000; i++)
    {
        binarySearch(ids, target, N);
    }
    end = std::chrono::steady_clock::now();
    std::chrono::duration<double, std::milli> binaryTime = end - start;
    std::cout << "Время линейного поиска: " << linearTime << std::endl;
    std::cout << "Время бинарного поиска: " << binaryTime << std::endl;
    return 0;
}
